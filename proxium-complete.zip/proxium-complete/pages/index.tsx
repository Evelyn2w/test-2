import { useState, useEffect } from 'react';

export default function Home() {
  const [url, setUrl] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [adCode, setAdCode] = useState('');

  useEffect(() => {
    fetch('/api/ad-code').then(res => res.text()).then(setAdCode);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/proxy?url=' + encodeURIComponent(url));
    const text = await res.text();
    setResponse(text);
    setLoading(false);
  };

  return (
    <div className="min-h-screen p-4 bg-gray-900 text-white flex flex-col items-center">
      <form onSubmit={handleSubmit} className="mb-4 w-full max-w-md">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Enter URL"
          className="p-2 rounded text-black w-full"
        />
        <button type="submit" className="mt-2 w-full p-2 bg-blue-600 rounded">Browse</button>
      </form>
      <div dangerouslySetInnerHTML={{ __html: adCode }} className="mb-4"></div>
      {loading ? <p>Loading...</p> : (
        <iframe srcDoc={response} sandbox="allow-same-origin allow-scripts" className="w-full h-[60vh] border rounded"></iframe>
      )}
    </div>
  );
}
