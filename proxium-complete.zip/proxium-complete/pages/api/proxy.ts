import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';
import { HttpsProxyAgent } from 'https-proxy-agent';
import fetch from 'node-fetch';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const targetUrl = req.query.url as string;
  if (!targetUrl) return res.status(400).send('URL is required');

  const proxyListPath = path.join(process.cwd(), 'data', 'proxies.json');
  const historyPath = path.join(process.cwd(), 'public', 'url-history.json');

  const proxies = JSON.parse(fs.readFileSync(proxyListPath, 'utf-8'));
  const proxy = proxies[Math.floor(Math.random() * proxies.length)];
  const agent = new HttpsProxyAgent(proxy);

  try {
    const fetchRes = await fetch(targetUrl, { agent });
    const body = await fetchRes.text();

    const log = { url: targetUrl, timestamp: new Date().toISOString() };
    const history = fs.existsSync(historyPath) ? JSON.parse(fs.readFileSync(historyPath, 'utf-8')) : [];
    history.push(log);
    fs.writeFileSync(historyPath, JSON.stringify(history, null, 2));

    res.setHeader('Content-Type', 'text/html');
    res.send(body);
  } catch {
    res.status(500).send('Proxy fetch failed');
  }
}
