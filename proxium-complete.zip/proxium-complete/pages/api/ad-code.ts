import fs from 'fs';
import path from 'path';
import { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const adPath = path.join(process.cwd(), 'data', 'ads.json');
  const data = JSON.parse(fs.readFileSync(adPath, 'utf-8'));
  res.setHeader('Content-Type', 'text/html');
  res.send(data.html || '');
}
