import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/admin-login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    if (res.ok) router.push('/admin');
    else alert('Login failed');
  };

  return (
    <div className="min-h-screen flex justify-center items-center bg-gray-800 text-white">
      <form onSubmit={handleLogin} className="bg-gray-900 p-6 rounded w-full max-w-sm">
        <h1 className="mb-4 text-xl">Admin Login</h1>
        <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" className="mb-2 p-2 rounded text-black w-full" />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="mb-2 p-2 rounded text-black w-full" />
        <button type="submit" className="bg-blue-600 p-2 rounded w-full">Login</button>
      </form>
    </div>
  );
}
