import { useEffect, useState } from 'react';

export default function Admin() {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    fetch('/url-history.json')
      .then(res => res.json())
      .then(setHistory);
  }, []);

  return (
    <div className="p-4 bg-gray-900 text-white min-h-screen">
      <h1 className="text-2xl mb-4">Analytics Dashboard</h1>
      <ul>
        {history.slice().reverse().map((entry, i) => (
          <li key={i} className="mb-1">{entry.timestamp} — {entry.url}</li>
        ))}
      </ul>
    </div>
  );
}
